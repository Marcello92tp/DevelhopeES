package esercizioPasquale;

public class GestoreOrdini {

}
