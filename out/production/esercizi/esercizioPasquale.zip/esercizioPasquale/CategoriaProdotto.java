package esercizioPasquale;

public enum CategoriaProdotto {SMARTPHONE, TABLET, HOMEPHONE, ACCESSORIES
}
